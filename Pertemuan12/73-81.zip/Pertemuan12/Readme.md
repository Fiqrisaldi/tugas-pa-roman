# 7.3: Broadcast receivers

* Task 1. Set up the PowerReceiver project 
* Task 2. Send and receive a custom broadcast 
* Coding challenge 
* Homework 
# 8.1: Notifications

* Task 1: Create a basic notification 
* Task 2: Update or cancel the notification 
* Task 3: Add a notification action button 
* Coding challenge 
* Homework 

